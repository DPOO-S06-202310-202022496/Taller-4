package uniandes.dpoo.taller4.interfaz;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.*;

public class PanelEstadisticas extends JPanel implements ActionListener {

	//Atributos interfaz
	private InterfazLightsOut principal;

	private JTextField textoJugadas;
	private JTextField textoJugador;
	
	public PanelEstadisticas( InterfazLightsOut pPrincipal, Color color1, Color color2)
	{
		principal = pPrincipal;
		
		setLayout(new GridLayout(1,4));
		setBackground(color1);
		
		JLabel etiquetaJugadas = new JLabel(" Jugadas: ");
		etiquetaJugadas.setHorizontalAlignment(JLabel.LEFT);
		etiquetaJugadas.setForeground(color2);
		
		textoJugadas = new JTextField();
		textoJugadas.setEditable(false);
		
		
		JLabel etiquetaJugador = new JLabel(" Jugador: ");
		etiquetaJugador.setHorizontalAlignment(JLabel.LEFT);
		etiquetaJugador.setForeground(color2);
		
		textoJugador = new JTextField();
		textoJugador.setEditable(false);
		
		add(etiquetaJugadas);
		add(textoJugadas);
		add(etiquetaJugador);
		add(textoJugador);
		
	}
	
	
	public void actualizarJugadas(int jugadas)
	{
		textoJugadas.setText(String.valueOf(jugadas));
	}
	
	public void actualizarJugador(String jugador)
	{
		textoJugador.setText(jugador);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	
	
}
