package uniandes.dpoo.taller4.interfaz;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.*;


public class PanelOpciones extends JPanel implements ActionListener {
	
	//Constantes para comandos de eventos
	private final static String NUEVO = "Nuevo";
	private final static String REINICIAR = "Reiniciar";
	private final static String TOP10 = "Top 10";
	private final static String CAMBIARJUGADOR = "Cambiar jugador";
	
	//Ventana principal de la aplicacion
	private InterfazLightsOut principal;
	
	//Atributos que contiene este panel
	private JButton botonNuevo;
	private JButton botonReiniciar;
	private JButton botonTop10;
	private JButton botonCambiarJugador;
	
	
	//Metodo constructor
	public PanelOpciones( InterfazLightsOut pPrincipal, Color color1, Color color2)
	{
		principal = pPrincipal;
		
		setLayout(new GridLayout(4,1));
		setBackground(color1);
		
		botonNuevo = new JButton(" NUEVO ");
		botonNuevo.setBackground(color2);
		botonNuevo.setActionCommand(NUEVO);
		botonNuevo.addActionListener(this);
		
		botonReiniciar = new JButton(" REINICIAR ");
		botonReiniciar.setBackground(color2);
		botonReiniciar.setActionCommand(REINICIAR);
		botonReiniciar.addActionListener(this);
		
		botonTop10 = new JButton(" TOP 10 ");
		botonTop10.setBackground(color2);
		botonTop10.setActionCommand(TOP10);
		botonTop10.addActionListener(this);
		
		botonCambiarJugador = new JButton(" CAMBIAR JUGADOR ");
		botonCambiarJugador.setBackground(color2);
		botonCambiarJugador.setActionCommand(CAMBIARJUGADOR);
		botonCambiarJugador.addActionListener(this);
		
		add(botonNuevo);
		add(botonReiniciar);
		add(botonTop10);
		add(botonCambiarJugador);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		String comando = e.getActionCommand();
		if(comando.equals(NUEVO))
		{
			System.out.println("nuevo");
			
		}
		else if(comando.equals(REINICIAR))
		{
			System.out.println("reiniciar");
			
		}
		else if(comando.equals(TOP10))
		{
			System.out.println("top 10");
		}
		else if(comando.equals(CAMBIARJUGADOR))
		{
			System.out.println("cambiar jugador");
		}
	}
	

}
