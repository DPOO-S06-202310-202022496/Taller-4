package uniandes.dpoo.taller4.interfaz;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.*;

public class PanelConfiguracion extends JPanel implements ActionListener{
	
	//Atributos de interfaz
	private InterfazLightsOut principal;
	
	private JComboBox comboSize;
	
	private JRadioButton easyButton;
	private JRadioButton mediumButton;
	private JRadioButton hardButton;
	
	public PanelConfiguracion( InterfazLightsOut pPrincipal, Color color1, Color color2)
	{
		principal = pPrincipal;
		
		setLayout(new FlowLayout());
		setBackground(color1);
		
		
		JLabel etiquetaComboSize = new JLabel(" Size: ");
		etiquetaComboSize.setHorizontalAlignment(JLabel.LEFT);
		etiquetaComboSize.setForeground(color2);
		
		comboSize = new JComboBox<String>();
		comboSize.setBounds(100,10,100,20);
		comboSize.addItem("5x5");
		comboSize.addItem("6x6");
		comboSize.addItem("7x7");
		comboSize.addItem("8x8");
		comboSize.addActionListener(this);
		
		JLabel etiquetaDificultad = new JLabel(" Dificulty: ");
		etiquetaDificultad.setHorizontalAlignment(JLabel.LEFT);	
		etiquetaDificultad.setForeground(color2);
		
		ButtonGroup grupoDificultad = new ButtonGroup();
		easyButton = new JRadioButton("easy", true);
		easyButton.setBackground(color1);
		easyButton.setForeground(color2);
		easyButton.addActionListener(this);
		
		
		mediumButton = new JRadioButton("medium", false);
		mediumButton.setBackground(color1);
		mediumButton.setForeground(color2);
		mediumButton.addActionListener(this);
		
		hardButton = new JRadioButton("hard", false);
		hardButton.setBackground(color1);
		hardButton.setForeground(color2);
		hardButton.addActionListener(this);
		
		grupoDificultad.add(easyButton);
		grupoDificultad.add(mediumButton);
		grupoDificultad.add(hardButton);
		
		
		
		add(etiquetaComboSize);
		add(comboSize);
		add(etiquetaDificultad);
		add(easyButton);
		add(mediumButton);
		add(hardButton);
	
		
	}
	


	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==comboSize)
		{
			String size = String.valueOf(comboSize.getSelectedItem());
			System.out.println(size);
		}
		else if(e.getSource()==easyButton)
		{
			System.out.println("easy");
		}
		else if(e.getSource()==mediumButton)
		{
			System.out.println("medium");
		}
		else if(e.getSource()==hardButton)
		{
			System.out.println("hard");
		}
	}
}
