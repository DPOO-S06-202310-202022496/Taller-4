package uniandes.dpoo.taller4.interfaz;

import javax.swing.*;
import javax.swing.border.LineBorder;

import uniandes.dpoo.taller4.modelo.Tablero;

import java.awt.*;
import java.awt.event.*;

public class PanelTablero extends JPanel implements MouseListener {

	private InterfazLightsOut principal;
	
	private JPanel panelTablero;
	
	
	public PanelTablero(InterfazLightsOut pPrincipal, Tablero tablero)
	{
		principal = pPrincipal;
		
		panelTablero = new JPanel();
			
	}
	
	private void eventoOyenteDeRaton()
	{
		//Agregar oyente de raton
		MouseListener oyenteDeRaton = new MouseListener()
		{
			@Override
			public void mouseClicked(MouseEvent me)
			{
				
			}
			
			@Override
			public void mousePressed(MouseEvent me)
			{
				
			}
			
			@Override
			public void mouseReleased(MouseEvent me)
			{
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override 
			public void mouseExited(MouseEvent me)
			{
				
			}

			
		};
		
		panelTablero.addMouseListener(oyenteDeRaton);
				
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	
}
