package uniandes.dpoo.taller4.interfaz;

import java.awt.*;
import java.io.*;
import java.util.*;
import javax.swing.*;
import uniandes.dpoo.taller4.modelo.*;


//Interfaz del juego Lights Out
public class InterfazLightsOut extends JFrame
{
	
	private ControllerModeloMundo controller;
	
	
	///NOTA: LA IMAGEN DEL TABLERO SE PONE EN UN JPANEL CON MOUSELISTENER
	private Tablero tablero;
	
	private PanelConfiguracion panelConfiguracion;
	private PanelTablero panelTablero;
	private PanelOpciones panelOpciones;
	private PanelEstadisticas panelEstadisticas;
	
	private Color color1;
	private Color color2;
	
	
	public InterfazLightsOut()
	{
		color1 = Color.black;
		color2 = Color.ORANGE;
		
		setSize(600,600);
		setResizable(false);
		setTitle("Lights Out");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		
		setLayout(new BorderLayout());
		
		//Crea el tablero
		tablero = new Tablero(5);
		
		panelConfiguracion = new PanelConfiguracion(this, color1, color2);
		//norte.add( panelConfiguracion, BorderLayout.NORTH);
		add(panelConfiguracion, BorderLayout.NORTH);		
		
		panelEstadisticas = new PanelEstadisticas(this, color1, color2 );
		add(panelEstadisticas, BorderLayout.SOUTH);
		
		panelOpciones = new PanelOpciones(this, color1, color2);
		add(panelOpciones, BorderLayout.EAST);
		
		
		panelTablero = new PanelTablero(this, tablero);
		add(panelTablero, BorderLayout.WEST);
		
		
				
	}
	
	public void actualizarPanelTablero()
	{
		remove(panelTablero);
		//Panel tablero
		panelTablero = new PanelTablero(this, tablero);
		add(panelTablero, BorderLayout.WEST);
		validate();
	}
	

	public static void main(String[] pArgs)
	{
		InterfazLightsOut interfaz = new InterfazLightsOut();
		interfaz.setVisible(true);

	}
	

}
