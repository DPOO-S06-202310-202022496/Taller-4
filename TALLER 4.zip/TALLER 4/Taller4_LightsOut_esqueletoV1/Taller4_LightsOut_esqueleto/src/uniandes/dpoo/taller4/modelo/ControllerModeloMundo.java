package uniandes.dpoo.taller4.modelo;

public class ControllerModeloMundo {

}
